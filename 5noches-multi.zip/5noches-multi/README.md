# 🎮 5 Noches con mi Tío — Multijugador Online

Un clon de FNAF con modo multijugador asimétrico: **1 jugador es el Guardia**, el resto controlan cada **Tío** manualmente en tiempo real.

## Cómo funciona el modo multijugador

| Rol | Qué hace |
|-----|----------|
| 🔦 **Guardia** | Juega normalmente — gestiona puertas, cámaras y energía |
| 👤 **Tío Pepe / Carlos / Manolo / Paco** | Decide cuándo moverse entre cámaras y cuándo atacar la puerta |

Hasta **5 jugadores** por sala (1 guardia + 4 tíos). Los tíos sin jugador los controla la IA normal.

---

## 🚀 Despliegue en Render (gratis)

### 1. Sube el proyecto a GitHub

```bash
git init
git add .
git commit -m "5 Noches con mi Tío - Multijugador"
git branch -M main
git remote add origin https://github.com/TU_USUARIO/5noches-multiplayer.git
git push -u origin main
```

### 2. Crea un Web Service en Render

1. Ve a [render.com](https://render.com) → **New → Web Service**
2. Conecta tu repositorio de GitHub
3. Configura:
   - **Name:** `5noches-multiplayer` (o el que quieras)
   - **Runtime:** `Node`
   - **Build Command:** `npm install`
   - **Start Command:** `npm start`
   - **Instance Type:** `Free`
4. Haz click en **Create Web Service**
5. Espera ~2 minutos → obtendrás una URL tipo `https://5noches-multiplayer.onrender.com`

> ⚠️ **Nota Render Free:** El servicio se "duerme" tras 15 min de inactividad. La primera petición tarda ~30s en despertar.

---

## 💻 Jugar en local

```bash
npm install
npm start
# Abre http://localhost:3000
```

---

## 🎮 Cómo jugar en multijugador

1. El primer jugador pulsa **🎮 MULTIJUGADOR ONLINE** → **Crear Sala**
2. Comparte el código de 5 letras con los demás
3. Los otros jugadores pulsan **Unirse a Sala** e introducen el código
4. Cada jugador que se une recibe un tío automáticamente (Pepe, Carlos, Manolo, Paco)
5. Cuando todos estén listos, el **host** elige la noche y pulsa **▶ Iniciar Partida**

### Controles del Tío (jugadores no-guardia)
- **Mapa de cámaras:** Click en cualquier cámara para moverte ahí
- **💀 Rush a la puerta:** Apareces en la puerta — si está abierta, ganas
- **← Retirarse:** Vuelves a una posición segura
- **Cooldown de 2.5s** entre movimientos

### Estrategia para los Tíos
- Vigila qué cámara mira el guardia (se marca en verde 👁)
- Ataca cuando su energía esté baja (< 20%)
- Coordínate con los otros tíos en el chat para atacar por ambas puertas a la vez

---

## Estructura del proyecto

```
5noches-multi/
├── server.js          # Servidor Node.js + Socket.io
├── package.json       # Dependencias
├── README.md
└── public/
    └── index.html     # Todo el juego (CSS + HTML + JS en un solo archivo)
```

## Tecnologías

- **Frontend:** HTML5, CSS3, JavaScript puro + SVG
- **Backend:** Node.js + Express + Socket.io
- **Audio:** Web Audio API (sin archivos de audio externos)
- **Despliegue:** Render.com (gratuito)
